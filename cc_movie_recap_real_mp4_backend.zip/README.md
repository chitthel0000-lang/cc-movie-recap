# CC Movie Recap

## Run
1. Install Node.js.
2. Install FFmpeg and make sure `ffmpeg` is available in PATH.
3. In this folder run:
   npm install
   npm start
4. Open http://localhost:3000

The `/api/export` endpoint creates a real MP4 with FFmpeg.
Next production steps: connect an authorized video/transcript source, an LLM for recap generation, Myanmar TTS, subtitle timing, and FFmpeg video composition.
