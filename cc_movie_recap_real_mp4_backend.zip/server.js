const express = require("express");
const path = require("path");
const fs = require("fs");
const { execFile } = require("child_process");

const app = express();
const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, "public");
const OUT = path.join(__dirname, "output");
fs.mkdirSync(OUT, { recursive: true });

app.use(express.json({limit:"2mb"}));
app.use(express.static(PUBLIC));

app.post("/api/export", (req,res)=>{
  const { title="CC Movie Recap", text="မြန်မာ Movie Recap" } = req.body || {};
  const safeTitle = String(title).replace(/[^a-zA-Z0-9_-]/g,"_").slice(0,60) || "recap";
  const output = path.join(OUT, `${safeTitle}-${Date.now()}.mp4`);

  // Requires FFmpeg installed on the server.
  // Generates a real MP4 from a simple title/recap card.
  const filter =
    "color=c=black:s=1280x720:r=30," +
    "drawtext=text='CC Movie Recap':fontcolor=white:fontsize=60:x=70:y=180," +
    "drawtext=text='Myanmar Movie Recap':fontcolor=white:fontsize=44:x=70:y=280," +
    "drawtext=text='Exported with FFmpeg':fontcolor=gray:fontsize=30:x=70:y=370";

  execFile("ffmpeg", [
    "-y","-f","lavfi","-i",filter,
    "-t","5","-c:v","libx264","-pix_fmt","yuv420p","-movflags","+faststart",
    output
  ], (error)=>{
    if(error){
      return res.status(500).json({
        error:"FFmpeg မတွေ့ပါ။ Server မှာ FFmpeg install လုပ်ပေးရပါမယ်။",
        details:error.message
      });
    }
    res.download(output, path.basename(output), ()=>{
      fs.unlink(output, ()=>{});
    });
  });
});

app.listen(PORT, ()=>console.log(`CC Movie Recap running: http://localhost:${PORT}`));
